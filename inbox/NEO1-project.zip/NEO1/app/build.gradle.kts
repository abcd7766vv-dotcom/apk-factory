import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The OpenRouter key is baked into the APK at BUILD time (env var or local.properties),
// so the app never asks for it, and it never lives in the source code / git history.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val orKey: String = System.getenv("OPENROUTER_KEY") ?: localProps.getProperty("OPENROUTER_KEY", "")

android {
    namespace = "com.neo.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.neo.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "OPENROUTER_KEY", "\"$orKey\"")
    }
    signingConfigs {
        create("neo") {
            storeFile = rootProject.file("neo.jks"); storePassword = "neo123456"
            keyAlias = "neo"; keyPassword = "neo123456"
        }
    }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("neo") } }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
}
