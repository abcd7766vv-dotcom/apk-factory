package com.neo.assistant

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** Direct (non-accessibility) device actions. */
class Device(private val ctx: Context) {
    private val http = OkHttpClient()

    val appLabels: String by lazy {
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.distinct().sorted().take(80).joinToString(", ")
    }

    private fun start(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

    fun openApp(name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "app not found: $name"
        val li = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "no launch intent"
        start(li)
        return "opened ${hit.loadLabel(pm)}"
    }

    fun openUrl(url: String): String { start(Intent(Intent.ACTION_VIEW, Uri.parse(url))); return "opened $url" }

    fun youtube(q: String): String {
        val u = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(q)}")
        return try {
            start(Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.youtube")); "youtube search opened"
        } catch (e: ActivityNotFoundException) { start(Intent(Intent.ACTION_VIEW, u)); "youtube (browser) opened" }
    }

    fun dial(number: String): String { start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))); return "dialer opened (Boss must press call)" }

    fun copy(text: String): String {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("NEO", text))
        return "copied to clipboard"
    }

    fun addEvent(title: String, iso: String): String {
        val ms = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(iso)?.time ?: return "bad date"
        val cr = ctx.contentResolver
        val cal = cr.query(CalendarContract.Calendars.CONTENT_URI, arrayOf(CalendarContract.Calendars._ID), null, null, null)
            ?.use { if (it.moveToFirst()) it.getLong(0) else null } ?: return "no calendar found"
        val v = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, cal); put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DTSTART, ms); put(CalendarContract.Events.DTEND, ms + 3_600_000)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        cr.insert(CalendarContract.Events.CONTENT_URI, v)
        return "event added"
    }

    suspend fun fetchText(url: String): String = withContext(Dispatchers.IO) {
        val r = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 NEO").build()
        http.newCall(r).execute().use { res ->
            res.body?.string().orEmpty()
                .replace(Regex("(?s)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").take(6000)
        }
    }
}
