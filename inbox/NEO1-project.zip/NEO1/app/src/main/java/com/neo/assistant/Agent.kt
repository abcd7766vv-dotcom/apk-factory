package com.neo.assistant

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The brain loop:  Boss speaks -> LLM plans JSON actions -> NEO executes -> observes SCREEN -> repeats until done.
 * Safety: risky screen buttons need a spoken "yes"; the model must also ask before irreversible things.
 * Learning: the model can emit "lesson" strings which are stored and fed back on every future task.
 */
class Agent {
    private val handler = CoroutineExceptionHandler { _, e -> Neo.log("⚠ ${e.message}"); Neo.setStatus("প্রস্তুত • শুনছি") }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + handler)
    private var job: Job? = null
    @Volatile private var pending: CompletableDeferred<Boolean>? = null
    private val hist = ArrayList<Pair<String, String>>()

    private val yes = Regex("(হ্যাঁ|হ্যা|হাঁ|ঠিক আছে|করো|করুন|yes|yeah|ok|okay|sure|confirm|go ahead)", RegexOption.IGNORE_CASE)
    private val stop = Regex("^\\s*(stop|cancel|থামো|থামুন|বন্ধ করো|বাদ দাও)", RegexOption.IGNORE_CASE)
    private val risky = Regex("send|pay|buy|purchase|order|delete|remove|uninstall|transfer|post|পাঠ|পেমেন্ট|কিন|ডিলিট|মুছ|ট্রান্সফার|অর্ডার", RegexOption.IGNORE_CASE)
    private val noA11y = "accessibility service is OFF (Boss must enable it)"

    fun say(t: String) { Neo.log("NEO: $t"); Neo.voice.speak(t) }

    fun submit(text: String) {
        Neo.log("Boss: $text")
        pending?.let { it.complete(yes.containsMatchIn(text)); return }
        if (stop.containsMatchIn(text)) { job?.cancel(); Neo.setStatus("প্রস্তুত • শুনছি"); say("Boss, থামালাম।"); return }
        job?.cancel()
        job = scope.launch { run(text) }
    }

    private suspend fun confirm(prompt: String): Boolean {
        say(prompt)
        val d = CompletableDeferred<Boolean>(); pending = d
        return try { withTimeout(25_000) { d.await() } } catch (_: TimeoutCancellationException) { false } finally { pending = null }
    }

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val les = Neo.mem.lessons().joinToString("\n") { "- $it" }
        return """You are NEO 1.0, the autonomous AI agent living inside Boss's Android phone. Always call the user "Boss".
Reply in Bengali (বাংলা) unless Boss speaks English. "say" is read aloud: keep it to 1-2 short sentences.
Now: $now. Installed apps: ${Neo.dev.appLabels}
What you learned about Boss so far:
$les

OUTPUT: exactly ONE JSON object, nothing else:
{"say":"spoken reply","actions":[...],"done":true|false,"lesson":"optional short note about Boss's preference","ui":{"theme":"#RRGGBB","eye":"#RRGGBB","lang":"bn-BD|en-US"}}
Include "ui" only when Boss asks to change HUD/theme color, avatar laser-eye color, or speech language.
ACTIONS ("a"): open_app{name} youtube{q} url{url} web{q} fetch{url} click{id|text} type{id,text} enter scroll{dir:up|down} back home recents wait{ms} see calendar{title,when:"yyyy-MM-ddTHH:mm"} copy{text} dial{number}
- web = live web research (returns findings). fetch = read a web page's text (scraping).
- After actions with done=false you receive RESULTS and SCREEN (numbered UI elements: click/type by [id]). Use "see" to get a screenshot when the text list is not enough.
- Work in small steps, verify on SCREEN, and try a different approach if something fails. Set done=true when finished, or when just chatting (actions []).
SAFETY: Never do harmful, illegal or deceptive things. Before sending messages, calling, paying, buying, deleting, installing or anything irreversible: FIRST ask Boss in "say" with actions [] and done=true; act only after Boss says yes. Never type passwords, OTPs or card numbers.
If a camera image is attached it is Boss's live video: recognise and describe what you see.
For long drafts (client replies, emails) use copy{text} and tell Boss it is copied."""
    }

    private fun parse(s: String): JSONObject? = try {
        val a = s.indexOf('{'); val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) null else JSONObject(s.substring(a, b + 1))
    } catch (_: Exception) { null }

    private suspend fun run(text: String) {
        Neo.setStatus("চিন্তা করছি…")
        val msgs = JSONArray().put(Neo.llm.sys(system()))
        hist.takeLast(6).forEach { (u, a) ->
            msgs.put(JSONObject().put("role", "user").put("content", u))
            msgs.put(JSONObject().put("role", "assistant").put("content", a))
        }
        msgs.put(Neo.llm.userMsg(text, if (Neo.videoOn) Neo.frameProvider?.invoke() else null))

        for (step in 1..12) {
            currentCoroutineContext().ensureActive()
            val raw = try { Neo.llm.chat(msgs, true) }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) { say("Boss, নেটওয়ার্ক বা API-তে সমস্যা হচ্ছে।"); Neo.log("⚠ ${e.message}"); break }
            msgs.put(JSONObject().put("role", "assistant").put("content", raw))
            val j = parse(raw) ?: JSONObject().put("say", raw).put("done", true)

            val msg = j.optString("say")
            if (msg.isNotBlank()) say(msg)
            applyUi(j.optJSONObject("ui"))
            j.optString("lesson").takeIf { it.isNotBlank() }?.let { Neo.mem.addLesson(it) }

            val acts = j.optJSONArray("actions") ?: JSONArray()
            val res = StringBuilder(); var wantShot = false
            for (i in 0 until acts.length()) {
                val a = acts.getJSONObject(i)
                if (a.optString("a") == "see") wantShot = true
                res.append(a.optString("a")).append(" → ").append(exec(a)).append('\n')
            }
            if (j.optBoolean("done", acts.length() == 0)) {
                if (acts.length() > 0) { Neo.setHud("auto", "শেষ কাজ সম্পন্ন ✓"); say("Boss, task completed successfully.") }
                hist.add(text to msg); Neo.setStatus("প্রস্তুত • শুনছি"); return
            }
            delay(700)
            val s = NeoAccessibilityService.i
            val shot = if (wantShot) s?.screenshot() else null
            msgs.put(Neo.llm.userMsg("RESULTS:\n$res\nSCREEN:\n${s?.dump() ?: "(accessibility off)"}", shot))
        }
        Neo.setStatus("প্রস্তুত • শুনছি")
    }

    private suspend fun exec(a: JSONObject): String = try {
        val d = Neo.dev; val s = NeoAccessibilityService.i
        when (val k = a.optString("a")) {
            "open_app" -> { Neo.setHud("auto", "অ্যাপ: ${a.optString("name")}"); d.openApp(a.optString("name")) }
            "youtube" -> { Neo.setHud("yt", "খুঁজছি: ${a.optString("q")}"); d.youtube(a.optString("q")) }
            "url" -> d.openUrl(a.optString("url"))
            "web" -> { Neo.setHud("web", "রিসার্চ: ${a.optString("q")}"); web(a.optString("q")) }
            "fetch" -> { Neo.setHud("web", "স্ক্র্যাপ: ${a.optString("url").take(28)}"); d.fetchText(a.optString("url")) }
            "click" -> click(s, a)
            "type" -> s?.type(a.optInt("id", -1), a.optString("text")) ?: noA11y
            "enter" -> s?.enter() ?: noA11y
            "scroll" -> s?.scroll(a.optString("dir", "down")) ?: noA11y
            "back", "home", "recents" -> s?.nav(k) ?: noA11y
            "wait" -> { delay(a.optLong("ms", 800).coerceIn(100, 5000)); "ok" }
            "see" -> "screenshot attached to next message"
            "calendar" -> { Neo.setHud("cal", "ইভেন্ট: ${a.optString("title")}"); d.addEvent(a.optString("title"), a.optString("when")) }
            "copy" -> d.copy(a.optString("text"))
            "dial" -> d.dial(a.optString("number"))
            else -> "unknown action: $k"
        }
    } catch (e: CancellationException) { throw e } catch (e: Exception) { "error: ${e.message}" }

    private suspend fun click(s: NeoAccessibilityService?, a: JSONObject): String {
        s ?: return noA11y
        val id = a.optInt("id", -1)
        val label = if (id >= 0) s.label(id) else a.optString("text")
        if (risky.containsMatchIn(label) && !confirm("Boss, '$label' চাপবো? হ্যাঁ বা না বলুন।")) return "denied by Boss"
        Neo.setHud("auto", "ক্লিক: ${label.take(20)}")
        val ok = if (id >= 0) s.click(id) else s.clickText(a.optString("text"))
        return if (ok) "clicked" else "click failed"
    }

    private suspend fun web(q: String): String {
        val m = JSONArray().put(Neo.llm.sys("You are a research assistant. Give concise, factual findings with source names. Max 250 words."))
            .put(Neo.llm.userMsg(q))
        return Neo.llm.chat(m, false, Config.MODEL + ":online")   // OpenRouter live web search
    }

    private fun applyUi(u: JSONObject?) {
        u ?: return
        try { u.optString("theme").takeIf { it.startsWith("#") }?.let { Neo.mem.theme = Color.parseColor(it) } } catch (_: Exception) {}
        try { u.optString("eye").takeIf { it.startsWith("#") }?.let { Neo.mem.eye = Color.parseColor(it) } } catch (_: Exception) {}
        u.optString("lang").takeIf { it.isNotBlank() }?.let { Neo.mem.lang = it }
        Neo.notifyUi()
    }
}
