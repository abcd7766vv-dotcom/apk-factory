package com.neo.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class LLM(private val ctx: Context) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()

    suspend fun chat(msgs: JSONArray, json: Boolean = false, model: String = Config.MODEL): String =
        withContext(Dispatchers.IO) {
            var err: Exception? = null
            repeat(3) { n ->
                try {
                    val body = JSONObject().put("model", model).put("messages", msgs)
                    if (json) body.put("response_format", JSONObject().put("type", "json_object"))
                    val req = Request.Builder().url(Config.URL)
                        .header("Authorization", "Bearer ${Config.key(ctx)}")
                        .header("HTTP-Referer", "https://neo.app").header("X-Title", "NEO 1.0")
                        .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                    http.newCall(req).execute().use { r ->
                        val s = r.body?.string().orEmpty()
                        if (!r.isSuccessful) throw IOException("HTTP ${r.code} ${s.take(150)}")
                        return@withContext JSONObject(s).getJSONArray("choices").getJSONObject(0)
                            .getJSONObject("message").getString("content")
                    }
                } catch (e: Exception) {
                    err = e
                    delay(700L * (n + 1))   // retry with backoff = crash-free networking
                }
            }
            throw err ?: IOException("unknown error")
        }

    fun sys(text: String): JSONObject = JSONObject().put("role", "system").put("content", text)

    fun userMsg(text: String, jpegB64: String? = null): JSONObject {
        if (jpegB64 == null) return JSONObject().put("role", "user").put("content", text)
        val parts = JSONArray()
            .put(JSONObject().put("type", "text").put("text", text))
            .put(JSONObject().put("type", "image_url")
                .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$jpegB64")))
        return JSONObject().put("role", "user").put("content", parts)
    }
}
