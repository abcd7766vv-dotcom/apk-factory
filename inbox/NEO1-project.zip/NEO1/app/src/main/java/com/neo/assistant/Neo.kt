package com.neo.assistant

import android.app.AlarmManager
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/** Process-wide core: shared state for HUD, voice, agent. */
object Neo {
    lateinit var app: Application
    lateinit var mem: Memory
    lateinit var llm: LLM
    lateinit var dev: Device
    lateinit var voice: Voice
    lateinit var agent: Agent

    val hud = ConcurrentHashMap<String, String>().apply {
        put("web", "অপেক্ষায়"); put("yt", "অপেক্ষায়"); put("auto", "অপেক্ষায়"); put("cal", "অপেক্ষায়")
    }
    @Volatile var status = "প্রস্তুত • শুনছি"
    @Volatile var level = 0f
    @Volatile var speaking = false
    @Volatile var videoOn = false
    @Volatile var uiVisible = false
    @Volatile var muted = false
    @Volatile var greeted = false
    var frameProvider: (() -> String?)? = null

    val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val logBuf = StringBuilder()
    private val main = Handler(Looper.getMainLooper())

    fun init(a: Application) {
        app = a
        mem = Memory(a); llm = LLM(a); dev = Device(a); agent = Agent()
        voice = Voice(a) { agent.submit(it) }
    }

    fun setHud(k: String, v: String) { hud[k] = v; notifyUi() }
    fun setStatus(s: String) { status = s; notifyUi() }
    fun log(line: String) {
        synchronized(logBuf) { logBuf.append(line).append('\n'); if (logBuf.length > 4000) logBuf.delete(0, 1500) }
        notifyUi()
    }
    fun logText(): String = synchronized(logBuf) { logBuf.toString() }
    fun notifyUi() { main.post { listeners.forEach { try { it() } catch (_: Exception) {} } } }

    /** Best-effort self-restart of the foreground service (crash / task removed). */
    fun scheduleRestart(c: Context, ms: Long) {
        try {
            val i = Intent(c, NeoService::class.java)
            val fl = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val pi = if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(c, 7, i, fl)
                     else PendingIntent.getService(c, 7, i, fl)
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                .set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + ms, pi)
        } catch (_: Throwable) {}
    }
}
