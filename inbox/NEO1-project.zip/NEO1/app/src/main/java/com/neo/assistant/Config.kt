package com.neo.assistant

import android.content.Context

/** API / network configuration manager. Key comes from BuildConfig (injected at build time). */
object Config {
    const val URL = "https://openrouter.ai/api/v1/chat/completions"
    // Vision-capable, fast model. Change here if you want another OpenRouter model.
    const val MODEL = "google/gemini-2.5-flash"

    fun key(ctx: Context): String =
        BuildConfig.OPENROUTER_KEY.ifBlank {
            ctx.getSharedPreferences("neo", Context.MODE_PRIVATE).getString("key", "") ?: ""
        }
}
