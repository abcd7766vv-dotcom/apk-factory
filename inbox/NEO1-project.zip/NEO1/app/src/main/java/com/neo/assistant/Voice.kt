package com.neo.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/** Hands-free loop: listen -> onHeard -> speak -> listen. Recognition pauses while NEO talks (no echo). */
class Voice(private val ctx: Context, private val onHeard: (String) -> Unit) : RecognitionListener {
    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private val queued = AtomicInteger(0)
    @Volatile var active = false
    @Volatile private var speaking = false
    private var lastBeat = 0L
    private var lastSpeak = 0L

    init {
        tts = TextToSpeech(ctx) { ready = it == TextToSpeech.SUCCESS }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) = finished()
            @Deprecated("Deprecated in Java") override fun onError(id: String?) = finished()
        })
    }

    private fun finished() {
        if (queued.decrementAndGet() <= 0) { queued.set(0); speaking = false; Neo.speaking = false; retry(250) }
    }

    fun start() { active = true; listen() }

    fun stop() { active = false; main.post { sr?.destroy(); sr = null; Neo.level = 0f } }

    fun speak(text: String, tries: Int = 0) {
        main.post {
            if (!ready && tries < 25) { main.postDelayed({ speak(text, tries + 1) }, 300); return@post }
            val bn = text.any { it in '\u0980'..'\u09FF' }
            tts?.language = if (bn) Locale("bn", "BD") else Locale.US
            speaking = true; Neo.speaking = true; lastSpeak = SystemClock.elapsedRealtime()
            sr?.cancel()
            queued.incrementAndGet()
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "u${System.nanoTime()}")
        }
    }

    private fun retry(ms: Long) { main.postDelayed({ listen() }, ms) }

    private fun listen() {
        main.post {
            if (!active || speaking) return@post
            try {
                if (sr == null) sr = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(this) }
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Neo.mem.lang)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                sr?.startListening(i)
                lastBeat = SystemClock.elapsedRealtime()
            } catch (e: Exception) { sr?.destroy(); sr = null; retry(1500) }
        }
    }

    /** Called by the watchdog: fixes stuck TTS / hung recognizer. */
    fun heal() {
        main.post {
            val now = SystemClock.elapsedRealtime()
            if (speaking && now - lastSpeak > 45_000) { speaking = false; Neo.speaking = false; queued.set(0) }
            if (active && !speaking && now - lastBeat > 20_000) { sr?.destroy(); sr = null; listen() }
        }
    }

    override fun onResults(b: Bundle?) {
        lastBeat = SystemClock.elapsedRealtime()
        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!t.isNullOrBlank()) try { onHeard(t) } catch (_: Exception) {}
        retry(300)
    }

    override fun onError(e: Int) {
        lastBeat = SystemClock.elapsedRealtime()
        if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == SpeechRecognizer.ERROR_CLIENT) { sr?.destroy(); sr = null }
        retry(if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 200 else 1200)
    }

    override fun onRmsChanged(v: Float) { Neo.level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
    override fun onEndOfSpeech() { Neo.level = 0f }
    override fun onReadyForSpeech(p: Bundle?) { lastBeat = SystemClock.elapsedRealtime() }
    override fun onBeginningOfSpeech() {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onPartialResults(b: Bundle?) {}
    override fun onEvent(t: Int, b: Bundle?) {}
}
