package com.neo.assistant

import android.content.Context
import org.json.JSONArray

/** Persistent memory: HUD look + "lessons" NEO learns about Boss (self-improvement loop). */
class Memory(ctx: Context) {
    private val p = ctx.getSharedPreferences("neo_mem", Context.MODE_PRIVATE)

    var theme: Int
        get() = p.getInt("theme", 0xFFFF2BD6.toInt())
        set(v) { p.edit().putInt("theme", v).apply() }
    var eye: Int
        get() = p.getInt("eye", 0xFFE040FB.toInt())
        set(v) { p.edit().putInt("eye", v).apply() }
    var lang: String
        get() = p.getString("lang", "bn-BD") ?: "bn-BD"
        set(v) { p.edit().putString("lang", v).apply() }

    fun lessons(): List<String> {
        val a = JSONArray(p.getString("lessons", "[]"))
        return List(a.length()) { a.getString(it) }
    }

    @Synchronized
    fun addLesson(s: String) {
        val l = lessons().toMutableList()
        if (s !in l) l.add(s.take(200))
        while (l.size > 40) l.removeAt(0)
        p.edit().putString("lessons", JSONArray(l).toString()).apply()
    }
}
