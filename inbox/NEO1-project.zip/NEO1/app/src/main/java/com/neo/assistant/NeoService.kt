package com.neo.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*

/** Auto-healing foreground service + small HUD overlay shown on top of other apps. */
class NeoService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var overlay: TextView? = null
    private var started = false
    private val ui: () -> Unit = { updateOverlay() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        if (!started) {
            started = true
            Neo.listeners.add(ui)
            scope.launch { while (isActive) { delay(10_000); try { heal() } catch (_: Exception) {} } }
        }
        return START_STICKY
    }

    private fun tryFg(n: Notification, type: Int): Boolean =
        try { ServiceCompat.startForeground(this, 1, n, type); true } catch (e: Exception) { false }

    private fun startFg() {
        if (Build.VERSION.SDK_INT >= 26)
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("neo", "NEO", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "neo").setSmallIcon(R.drawable.ic_neo)
            .setContentTitle("NEO 1.0 সক্রিয়").setContentText("Boss, আমি আছি।").setContentIntent(pi).setOngoing(true).build()
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && Neo.uiVisible
        val special = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        val both = special or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (mic && tryFg(n, both)) return
        if (tryFg(n, special)) return
        try { startForeground(1, n) } catch (e: Exception) { stopSelf() }
    }

    private fun heal() {
        Neo.voice.heal()
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk && Neo.uiVisible && !Neo.muted && !Neo.voice.active) Neo.voice.start()
        updateOverlay()
    }

    private fun updateOverlay() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (Neo.uiVisible || !Settings.canDrawOverlays(this)) { overlay?.let { wm.removeView(it) }; overlay = null; return }
            if (overlay == null) {
                val tv = TextView(this).apply {
                    setTextColor(Color.WHITE); textSize = 12f; setPadding(28, 12, 28, 12)
                    background = GradientDrawable().apply { setColor(0xCC200030.toInt()); cornerRadius = 30f; setStroke(2, Neo.mem.theme) }
                }
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 90 }
                wm.addView(tv, lp); overlay = tv
            }
            overlay?.text = "◉ NEO • ${Neo.status}"
        } catch (_: Exception) {}
    }

    override fun onTaskRemoved(rootIntent: Intent?) { Neo.scheduleRestart(this, 1500); super.onTaskRemoved(rootIntent) }

    override fun onDestroy() {
        Neo.listeners.remove(ui); scope.cancel()
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) {}
        Neo.scheduleRestart(this, 3000)
        super.onDestroy()
    }
}
