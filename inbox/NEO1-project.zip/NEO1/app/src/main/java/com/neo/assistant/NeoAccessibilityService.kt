package com.neo.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/** NEO's hands and eyes: reads the UI tree, taps, types, scrolls, takes screenshots. */
@SuppressLint("NewApi")
class NeoAccessibilityService : AccessibilityService() {
    companion object { @Volatile var i: NeoAccessibilityService? = null }

    private val nodes = ArrayList<AccessibilityNodeInfo>()

    override fun onServiceConnected() { i = this; Neo.setHud("auto", "Accessibility সংযুক্ত ✓") }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { i = null; return super.onUnbind(intent) }
    override fun onDestroy() { i = null; super.onDestroy() }

    private fun label(n: AccessibilityNodeInfo) = (n.text ?: n.contentDescription)?.toString()?.take(50)

    /** Numbered list of visible, useful UI elements — this is what the LLM "sees". */
    @Synchronized fun dump(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(screen unavailable)"
        val sb = StringBuilder("app=${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || nodes.size >= 120) return
            val t = label(n)
            if (n.isVisibleToUser && (n.isClickable || n.isEditable || n.isScrollable || !t.isNullOrBlank())) {
                nodes.add(n)
                val r = Rect(); n.getBoundsInScreen(r)
                sb.append("[${nodes.size - 1}] ${n.className?.toString()?.substringAfterLast('.')} \"${t ?: ""}\"")
                    .append(if (n.isClickable) " click" else "").append(if (n.isEditable) " edit" else "")
                    .append(if (n.isScrollable) " scroll" else "").append(" @${r.centerX()},${r.centerY()}\n")
            }
            for (k in 0 until n.childCount) walk(n.getChild(k))
        }
        walk(root)
        return sb.toString()
    }

    fun label(idx: Int): String = nodes.getOrNull(idx)?.let { label(it) } ?: ""

    fun click(idx: Int): Boolean {
        val n = nodes.getOrNull(idx) ?: return false
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        val r = Rect(); n.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun clickText(t: String): Boolean {
        val idx = nodes.indexOfFirst { label(it)?.contains(t, true) == true }
        return idx >= 0 && click(idx)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }

    fun scroll(dir: String): String {
        val m = resources.displayMetrics; val x = m.widthPixels / 2f
        val (a, b) = if (dir == "up") (m.heightPixels * 0.3f to m.heightPixels * 0.7f) else (m.heightPixels * 0.7f to m.heightPixels * 0.3f)
        val p = Path().apply { moveTo(x, a); lineTo(x, b) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build(), null, null)
        return if (ok) "scrolled $dir" else "scroll failed"
    }

    fun type(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: nodes.firstOrNull { it.isEditable } ?: return "no input field"
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "typed" else "type failed"
    }

    fun enter(): String {
        if (Build.VERSION.SDK_INT >= 30) {
            val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (n != null && n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return "enter sent"
        }
        return "enter failed (click the search/submit button instead)"
    }

    fun nav(w: String): String {
        val a = when (w) { "back" -> GLOBAL_ACTION_BACK; "home" -> GLOBAL_ACTION_HOME; else -> GLOBAL_ACTION_RECENTS }
        return if (performGlobalAction(a)) "ok" else "failed"
    }

    /** Screenshot -> small JPEG base64 (Android 11+). Lets the model truly "see" the screen. */
    suspend fun screenshot(): String? = suspendCancellableCoroutine { c ->
        if (Build.VERSION.SDK_INT < 30) { c.resume(null); return@suspendCancellableCoroutine }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp == null) { c.resume(null); return }
                    val s = Bitmap.createScaledBitmap(bmp, 540, (540f * bmp.height / bmp.width).toInt(), true)
                    val o = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 60, o)
                    c.resume(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP))
                } catch (e: Exception) { c.resume(null) }
            }
            override fun onFailure(code: Int) { c.resume(null) }
        })
    }
}
