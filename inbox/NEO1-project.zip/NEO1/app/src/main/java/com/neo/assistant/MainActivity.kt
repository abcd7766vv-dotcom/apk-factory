package com.neo.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val bodies = HashMap<String, TextView>()
    private val neons = ArrayList<GradientDrawable>()
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var preview: PreviewView
    private lateinit var input: EditText
    @Volatile private var lastFrame: String? = null
    private var cam: ProcessCameraProvider? = null
    private val ui: () -> Unit = { render() }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startNeo() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun neon() = GradientDrawable().apply {
        setColor(0x66200030); cornerRadius = dp(8).toFloat(); setStroke(dp(1), Neo.mem.theme); neons.add(this)
    }

    private fun panel(title: String, key: String): View {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)); background = neon()
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        }
        l.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD) })
        val b = TextView(this).apply { setTextColor(0xFFFFB3F0.toInt()); textSize = 11f; maxLines = 2 }
        l.addView(b); bodies[key] = b
        return l
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status); log = findViewById(R.id.log); scroll = findViewById(R.id.scroll)
        preview = findViewById(R.id.preview); input = findViewById(R.id.input)

        findViewById<LinearLayout>(R.id.rowA).apply { addView(panel("বিশ্বের নিয়ন্ত্রণ", "web")); addView(panel("নিখুঁত কমান্ড", "yt")) }
        findViewById<LinearLayout>(R.id.rowB).apply { addView(panel("মাস্টার কোড ২.০", "auto")); addView(panel("সিডিউল সিঙ্ক", "cal")) }
        input.background = neon()
        listOf(R.id.btnSend, R.id.btnMic, R.id.btnCam, R.id.btnSetup).forEach { findViewById<View>(it).background = neon() }

        fun send() {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.text.clear(); Neo.agent.submit(t) }
        }
        findViewById<View>(R.id.btnSend).setOnClickListener { send() }
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        findViewById<View>(R.id.btnMic).setOnClickListener {
            Neo.muted = !Neo.muted
            if (Neo.muted) { Neo.voice.stop(); Neo.setStatus("মিউট") } else { Neo.voice.start(); Neo.setStatus("প্রস্তুত • শুনছি") }
        }
        findViewById<View>(R.id.btnCam).setOnClickListener { toggleCamera() }
        findViewById<View>(R.id.btnSetup).setOnClickListener { setupDialog() }
        Neo.frameProvider = { lastFrame }

        val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
            Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
            .also { if (Build.VERSION.SDK_INT >= 33) it.add(Manifest.permission.POST_NOTIFICATIONS) }
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) startNeo() else permLauncher.launch(need.toTypedArray())
    }

    override fun onStart() {
        super.onStart(); Neo.uiVisible = true; Neo.listeners.add(ui); render()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            ContextCompat.startForegroundService(this, Intent(this, NeoService::class.java))
    }

    override fun onStop() { super.onStop(); Neo.uiVisible = false; Neo.listeners.remove(ui) }

    private fun startNeo() {
        ContextCompat.startForegroundService(this, Intent(this, NeoService::class.java))
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && !Neo.muted) Neo.voice.start()
        if (!Neo.greeted) { Neo.greeted = true; Neo.agent.say("Boss, NEO ওয়ান পয়েন্ট জিরো অনলাইন। বলুন, কী করতে হবে?") }
        if (Config.key(this).isBlank()) keyDialog() else if (!a11yOn()) setupDialog()
    }

    private fun keyDialog() {
        val et = EditText(this).apply { hint = "sk-or-v1-…"; setSingleLine(); setPadding(dp(20), dp(12), dp(20), dp(12)) }
        AlertDialog.Builder(this).setTitle("OpenRouter API key (একবারই)")
            .setMessage("Boss, key পেস্ট করুন। এটা শুধু এই ফোনেই সংরক্ষিত থাকবে।")
            .setView(et).setCancelable(false)
            .setPositiveButton("সংরক্ষণ") { _, _ ->
                getSharedPreferences("neo", MODE_PRIVATE).edit().putString("key", et.text.toString().trim()).apply()
                if (!a11yOn()) setupDialog()
            }.show()
    }

    private fun a11yOn(): Boolean =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    /** One-time setup: after these 3 switches NEO runs for good. */
    private fun setupDialog() {
        AlertDialog.Builder(this).setTitle("এককালীন সেটআপ")
            .setItems(arrayOf(
                "১. Accessibility চালু করুন (NEO 1.0)",
                "২. অন্য অ্যাপের ওপর দেখানোর অনুমতি",
                "৩. ব্যাটারি অপটিমাইজেশন বন্ধ (আজীবন চালু থাকতে)",
                "৪. API key বদলান")) { _, w ->
                when (w) {
                    0 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    2 -> startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                    else -> keyDialog()
                }
            }.setNegativeButton("বন্ধ", null).show()
    }

    private fun toggleCamera() {
        if (Neo.videoOn) {
            cam?.unbindAll(); preview.visibility = View.GONE; Neo.videoOn = false; lastFrame = null
            Neo.agent.say("Boss, ভিডিও বন্ধ করলাম."); return
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(arrayOf(Manifest.permission.CAMERA)); return
        }
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get(); cam = p
            val pv = androidx.camera.core.Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            var last = 0L
            an.setAnalyzer(Executors.newSingleThreadExecutor()) { img ->
                try {
                    val now = SystemClock.elapsedRealtime()
                    if (now - last > 1000) { last = now; lastFrame = toB64(img) }
                } catch (_: Exception) {} finally { img.close() }
            }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, pv, an)
            preview.visibility = View.VISIBLE; Neo.videoOn = true
            Neo.agent.say("Boss, আপনাকে দেখতে পাচ্ছি। ভিডিও কল চালু।")
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toB64(img: ImageProxy): String {
        val bmp = img.toBitmap()
        val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        val s = Bitmap.createScaledBitmap(r, 512, (512f * r.height / r.width).toInt(), true)
        val o = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 60, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun render() {
        val th = Neo.mem.theme
        neons.forEach { it.setStroke(dp(1), th) }
        Neo.hud.forEach { (k, v) -> bodies[k]?.text = v }
        status.text = "◉ NEO 1.0 • ${Neo.status}"; status.setTextColor(th)
        log.text = Neo.logText(); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }
}
