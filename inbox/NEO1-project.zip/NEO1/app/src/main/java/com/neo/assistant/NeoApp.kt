package com.neo.assistant

import android.app.Application
import java.io.File
import java.util.Date

class NeoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.log").appendText("${Date()}\n${e.stackTraceToString()}\n\n") } catch (_: Throwable) {}
            Neo.scheduleRestart(this, 2000)   // auto-heal: bring the service back after a crash
            prev?.uncaughtException(t, e)
        }
        try { Neo.init(this) } catch (e: Throwable) {
            try { File(filesDir, "crash.log").appendText("init: ${e.stackTraceToString()}\n") } catch (_: Throwable) {}
        }
    }
}
