package com.neo.assistant

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Neon cyberpunk command-center canvas: energy streams, brain core, avatar with laser visor, audio spectrum. */
class HudView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bars = FloatArray(36)
    private val t0 = System.nanoTime()

    private fun dim(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    override fun onDraw(cv: Canvas) {
        val t = (System.nanoTime() - t0) / 1e9f
        val w = width.toFloat(); val h = height.toFloat()
        val th = Neo.mem.theme; val eye = Neo.mem.eye
        val lvl = if (Neo.speaking) 0.45f + 0.35f * abs(sin(t * 7f)) else Neo.level
        val cx = w / 2; val cy = h * 0.40f

        // background glow
        p.reset(); p.isAntiAlias = true
        p.shader = RadialGradient(cx, cy, h * 0.75f, intArrayOf(dim(th, 0.35f), 0xFF14001A.toInt(), 0xFF040006.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null

        // swirling energy streams
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        for (k in 0 until 8) {
            val path = Path()
            for (i in 0..140) {
                val ang = i * 0.13f + t * (0.5f + k * 0.06f) + k * 0.8f
                val r = 18f + i * w * 0.0062f * (1f + 0.15f * sin(t + k))
                val x = cx + cos(ang) * r; val y = cy + sin(ang) * r * 0.75f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.color = th; p.alpha = 70 + k * 14; p.strokeWidth = 1.5f + (k % 3) * 1.5f
            cv.drawPath(path, p)
        }

        // brain core (pulses with voice level)
        p.style = Paint.Style.FILL
        val cr = w * 0.13f * (1f + 0.25f * lvl)
        p.shader = RadialGradient(cx, cy, cr * 2f, intArrayOf(Color.WHITE, th, 0x00000000), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, cr * 2f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.alpha = 255; p.strokeWidth = 4f
        val bw = cr * 0.6f
        cv.drawOval(cx - bw, cy - bw * 0.8f, cx - 3f, cy + bw * 0.8f, p)
        cv.drawOval(cx + 3f, cy - bw * 0.8f, cx + bw, cy + bw * 0.8f, p)
        cv.drawArc(cx - bw * 0.8f, cy - bw * 0.4f, cx - 8f, cy + bw * 0.4f, 200f, 220f, false, p)
        cv.drawArc(cx + 8f, cy - bw * 0.4f, cx + bw * 0.8f, cy + bw * 0.4f, 120f, 220f, false, p)

        // avatar: shoulders, head, hair, laser visor
        p.style = Paint.Style.FILL
        val ay = h * 0.60f; val hr = w * 0.085f
        p.color = 0xFF1B0A22.toInt(); cv.drawRoundRect(cx - hr * 2.2f, ay + hr * 1.2f, cx + hr * 2.2f, ay + hr * 4f, 40f, 40f, p)
        p.color = th; p.alpha = 190; cv.drawArc(cx - hr * 1.3f, ay - hr * 1.4f, cx + hr * 1.3f, ay + hr * 1.7f, 180f, 180f, true, p)
        p.color = 0xFF8A5A44.toInt(); cv.drawOval(cx - hr, ay - hr * 1.1f, cx + hr, ay + hr * 1.2f, p)
        val vy = ay - hr * 0.1f
        for (g in 3 downTo 0) {
            p.color = eye; p.alpha = 45 + (3 - g) * 60
            cv.drawRoundRect(cx - hr * 1.1f - g * 4, vy - hr * 0.25f - g * 4, cx + hr * 1.1f + g * 4, vy + hr * 0.25f + g * 4, 20f, 20f, p)
        }

        // audio spectrum meter
        p.color = th; p.alpha = 230
        val by = h * 0.815f; val bwid = w * 0.84f / bars.size * 0.6f
        for (i in bars.indices) {
            val tgt = lvl * (0.35f + 0.65f * abs(sin(t * 4f + i * 0.6f))) + 0.03f
            bars[i] += (tgt - bars[i]) * 0.3f
            val bh = bars[i] * h * 0.06f
            val x = w * 0.08f + i * (w * 0.84f / bars.size)
            cv.drawRoundRect(x, by - bh, x + bwid, by + bh, 4f, 4f, p)
        }
        postInvalidateOnAnimation()
    }
}
