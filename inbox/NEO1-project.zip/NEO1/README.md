# NEO 1.0 — Autonomous Android AI Agent

## Easiest path: browser install page (GitHub, ~10 min, once)
1. Create a **public** GitHub repo, upload all files of this folder (incl. `docs/`, `neo.jks`).
2. Repo → Settings → Pages → Source: **GitHub Actions**.
3. Actions → "Build NEO APK and Site" → Run workflow (wait ~5 min).
4. Open `https://<username>.github.io/<repo>/` on your phone → tap the big button → install.
Every push rebuilds; the same link always serves the latest APK. The APK has NO key inside —
the app asks for the OpenRouter key once on first launch (stored only on the phone).


## Build (choose one)
### A) Cloud build from your phone (GitHub Actions)
1. Create a PRIVATE GitHub repo, upload everything in this folder.
2. Repo → Settings → Secrets and variables → Actions → New secret: `OPENROUTER_KEY` = your (new) OpenRouter key.
3. Actions tab → "Build NEO APK" → Run workflow → download artifact `NEO-1.0-apk` → install `app-debug.apk`.

### B) Android Studio
1. Copy `local.properties.example` to `local.properties`, set `OPENROUTER_KEY=...`
2. Open the folder in Android Studio (Ladybug or newer) → Build → Build APK(s).

## First run (one time only)
Allow Mic / Camera / Calendar / Notifications, then in the ⚙ dialog:
1. Enable Accessibility → NEO 1.0   2. Allow overlay   3. Disable battery optimisation.

## Voice examples
- "ইউটিউবে লো-ফাই মিউজিক চালাও"  - "কালকে বিকেল ৩টায় মিটিং সিডিউল করো"
- "থিম নীল করো / চোখের লেজার লাল করো"  - "বাংলাদেশের আজকের খবর রিসার্চ করো"
- 📹 চালু করে: "আমার হাতে এটা কী?"
- "থামো" = current task cancel.
