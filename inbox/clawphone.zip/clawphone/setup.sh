#!/data/data/com.termux/files/usr/bin/bash
# ClawPhone - একবার চালালেই সব সেটআপ হবে
DIR="$(cd "$(dirname "$0")" && pwd)"
source "$DIR/config.env"
say(){ printf "\n\033[1;32m==> %s\033[0m\n" "$*"; }

say "1/5 Termux আপডেট হচ্ছে"
termux-wake-lock 2>/dev/null
pkg update -y && pkg upgrade -y
pkg install -y curl git unzip termux-api nodejs || { echo "প্যাকেজ ইনস্টল হয়নি। ইন্টারনেট দেখে আবার চালান।"; exit 1; }

say "2/5 OpenClaw ইনস্টল হচ্ছে (৫-১৫ মিনিট লাগতে পারে)"
curl -fsSL https://raw.githubusercontent.com/mithun50/openclaw-termux/main/install.sh -o "$DIR/upstream-install.sh" || { echo "ডাউনলোড হয়নি"; exit 1; }
bash "$DIR/upstream-install.sh"
hash -r; source "$HOME/.bashrc" 2>/dev/null
command -v openclawx >/dev/null || npm install -g openclaw-termux
openclawx setup

say "3/5 OpenRouter API key সেট হচ্ছে"
echo "যদি Binding জিজ্ঞেস করে, 'Loopback (127.0.0.1)' বাছুন। বাকি সব প্রশ্নে Enter দিন।"
proot-distro login ubuntu -- bash -lc "source ~/.bashrc 2>/dev/null; openclaw onboard --auth-choice apiKey --token-provider openrouter --token '$OPENROUTER_API_KEY'"

say "4/5 অটো-রিস্টার্ট ও বুটে অটো-স্টার্ট বসানো হচ্ছে"
mkdir -p "$HOME/.clawphone" "$HOME/.termux/boot"
cp "$DIR/run.sh" "$DIR/stop.sh" "$HOME/.clawphone/"
chmod +x "$HOME/.clawphone/"*.sh
cat > "$HOME/.termux/boot/clawphone.sh" <<BOOT
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
nohup bash $HOME/.clawphone/run.sh >> $HOME/.clawphone/run.log 2>&1 &
BOOT
chmod +x "$HOME/.termux/boot/clawphone.sh"

say "5/5 চালু করা হচ্ছে"
nohup bash "$HOME/.clawphone/run.sh" >> "$HOME/.clawphone/run.log" 2>&1 &
sleep 40
echo
echo "ড্যাশবোর্ড: ব্রাউজারে http://127.0.0.1:18789 খুলুন"
echo "সমস্যা হলে দেখুন: tail -n 30 ~/.clawphone/gateway.log"
