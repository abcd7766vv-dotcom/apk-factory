#!/data/data/com.termux/files/usr/bin/bash
# গেটওয়ে বন্ধ হলে বা নেট ফিরলে নিজে থেকে আবার চালু করে
termux-wake-lock 2>/dev/null
mkdir -p "$HOME/.clawphone"
PIDF="$HOME/.clawphone/run.pid"
if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null; then echo "আগে থেকেই চলছে"; exit 0; fi
echo $$ > "$PIDF"
have_net(){ curl -s -m 5 -o /dev/null https://openrouter.ai; }
gateway_up(){ curl -s -m 3 -o /dev/null http://127.0.0.1:18789; }
while true; do
  if have_net && ! gateway_up; then
    echo "$(date) gateway চালু হচ্ছে"
    nohup openclawx start >> "$HOME/.clawphone/gateway.log" 2>&1 &
    sleep 30
  elif ! have_net; then
    echo "$(date) নেট নেই, অপেক্ষা করছে"
  fi
  sleep 15
done
