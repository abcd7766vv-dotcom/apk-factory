#!/data/data/com.termux/files/usr/bin/bash
kill "$(cat "$HOME/.clawphone/run.pid" 2>/dev/null)" 2>/dev/null
pkill -f "openclaw" 2>/dev/null
echo "বন্ধ করা হয়েছে"
