ClawPhone - Redmi 8 এ OpenClaw (OpenRouter দিয়ে)

আগে একবার করুন (F-Droid থেকে, Play Store থেকে নয়):
  1) Termux ইনস্টল করুন
  2) Termux:Boot ইনস্টল করে একবার খুলে বন্ধ করুন
  3) Termux:API ইনস্টল করুন

ফোনের অনুমতি (MIUI):
  - Settings > Apps > Manage apps > Termux > Autostart = ON
  - Settings > Apps > Manage apps > Termux > Battery saver = No restrictions
  - Termux:Boot এর জন্যও একই দুটো
  - Recent apps খুলে Termux কার্ড লক করুন (কার্ড নিচে টেনে লক আইকন)

সেটআপ (Termux এ, শুধু এই কয়টা লাইন):
  termux-setup-storage
  cd ~/storage/downloads
  unzip clawphone.zip
  bash clawphone/setup.sh

এরপর:
  - ড্যাশবোর্ড: ব্রাউজারে http://127.0.0.1:18789
  - ওয়াইফাই গেলে/এলে বা ফোন রিস্টার্ট হলে নিজে আবার চালু হবে
  - বন্ধ করতে: bash ~/.clawphone/stop.sh
  - লগ: tail -n 30 ~/.clawphone/gateway.log

কোনো এরর এলে স্ক্রিনশট পাঠান।
