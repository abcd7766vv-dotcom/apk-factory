import json,os
p=open('system_prompt.md',encoding='utf-8').read()
k=json.load(open('keys.local.json')) if os.path.exists('keys.local.json') else {}
t=open('assets/index.template.html',encoding='utf-8').read()
open('assets/index.html','w',encoding='utf-8').write(t.replace('__SYSTEM_PROMPT__',json.dumps(p,ensure_ascii=False)).replace('__DEFAULT_KEYS__',json.dumps(k)))
print('built assets/index.html')
