# Sumaiya Rani setup

1. Run `python build.py` (in `nova/`) to inject `system_prompt.md` into the template. Copy `assets/index.html` to `app/src/main/assets/`.
2. Put both `.kt` files in `com.example.nova`. Dependency: `androidx.appcompat`. minSdk 24 (screen capture itself needs Android 11+).

## AndroidManifest.xml (inside `<manifest>` / `<application>`)
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.CAMERA"/>
<queries><intent><action android:name="android.speech.RecognitionService"/></intent></queries>

<service android:name=".AssistantService" android:exported="false"
    android:label="Sumaiya Rani screen assistant"
    android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
  <intent-filter><action android:name="android.accessibilityservice.AccessibilityService"/></intent-filter>
  <meta-data android:name="android.accessibilityservice" android:resource="@xml/accessibility_service_config"/>
</service>
```

## res/xml/accessibility_service_config.xml
```xml
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagRetrieveInteractiveWindows"
    android:canRetrieveWindowContent="true"
    android:canPerformGestures="true"
    android:canTakeScreenshot="true"
    android:description="@string/a11y_description"
    android:notificationTimeout="100"/>
```
Add `a11y_description` to strings.xml, e.g. "Lets Sumaiya Rani see your screen, draw guidance marks, and tap when you approve."

## Enabling
Open Sumaiya Rani → ⚙ → "Enable screen access" → Settings → Installed apps → Sumaiya Rani → turn on. Android shows a warning; that is expected.
Play Store distribution needs an Accessibility API declaration; sideloading works without it.
