package com.example.nova

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val ui = Handler(Looper.getMainLooper())

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA), 1)
        tts = TextToSpeech(this) { if (tts.setLanguage(java.util.Locale("bn", "BD")) < 0) tts.setLanguage(java.util.Locale.getDefault()); tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) = js("onSpeakDone()")
            @Deprecated("") override fun onError(id: String?) = js("onSpeakDone()")
        }) }
        web = WebView(this).also { setContentView(it) }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false               // assets are served via file:///android_asset/ only
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = object : WebChromeClient() {  // needed for <input type=file capture> (camera)
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                filePathCb?.onReceiveValue(null); filePathCb = cb
                startActivityForResult(p.createIntent(), 7); return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("") override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rq == 7) { filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); filePathCb = null }
    }

    inner class Bridge {
        @JavascriptInterface fun isServiceOn() = AssistantService.instance != null
        @JavascriptInterface fun openAccessibilitySettings() = startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

        /** Sends Nova to the background so the screenshot shows the target app, not Nova's own UI. */
        @JavascriptInterface fun screenshot() {
            val s = AssistantService.instance ?: run { js("onScreenshot(null)"); return }
            if (android.os.Build.VERSION.SDK_INT < 30) { js("onScreenshot(null)"); return }
            runOnUiThread { moveTaskToBack(true) }
            ui.postDelayed({ s.screenshot { js(if (it == null) "onScreenshot(null)" else "onScreenshot(${JSONObject.quote(it)})") } }, 1200)
        }
        /** Native HTTPS POST so the WebView never hits CORS limits. Result returns through onHttp(id, code, body). */
        @JavascriptInterface fun http(id: Int, url: String, headers: String, body: String) {
            Thread {
                var code = 0; var text = ""
                try {
                    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 90000; c.doOutput = true
                    val h = JSONObject(headers); h.keys().forEach { c.setRequestProperty(it, h.getString(it)) }
                    c.outputStream.use { it.write(body.toByteArray()) }
                    code = c.responseCode
                    text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                } catch (e: Exception) { code = 0; text = e.message ?: "network error" }
                js("onHttp($id,$code,${JSONObject.quote(text)})")
            }.start()
        }
        @JavascriptInterface fun taskMode(on: Boolean) { AssistantService.instance?.taskMode(on) }
        @JavascriptInterface fun stopRequested(): Boolean = AssistantService.stopRequested
        @JavascriptInterface fun drawMarks(json: String) { AssistantService.instance?.showMarks(json) }
        @JavascriptInterface fun clearMarks() { AssistantService.instance?.clearMarks() }
        @JavascriptInterface fun perform(json: String): Boolean = runCatching { AssistantService.instance?.perform(JSONObject(json)) ?: false }.getOrDefault(false)

        @JavascriptInterface fun speak(t: String, rate: Float, pitch: Float) {
            tts.setSpeechRate(rate); tts.setPitch(pitch)
            tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
        @JavascriptInterface fun stopSpeaking() { tts.stop(); js("onSpeakDone()") }

        @JavascriptInterface fun startListening() = runOnUiThread {
            sr?.destroy()
            sr = SpeechRecognizer.createSpeechRecognizer(this@MainActivity).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onPartialResults(b: Bundle?) { text(b)?.let { js("onSpeech(${JSONObject.quote(it)},false)") } }
                    override fun onResults(b: Bundle?) { text(b)?.let { js("onSpeech(${JSONObject.quote(it)},true)") } ?: js("onListenEnd()") }
                    override fun onError(e: Int) = js("onListenEnd()")
                    override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}; override fun onEvent(t: Int, b: Bundle?) {}
                    fun text(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                })
                startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
            }
        }
    }

    override fun onDestroy() { sr?.destroy(); tts.shutdown(); super.onDestroy() }
}
