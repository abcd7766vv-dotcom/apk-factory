plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.nova"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.nova"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    // Release APKs are signed with the debug key, so they always install (unsigned APKs give "problem parsing the package")
    buildTypes { release { signingConfig = signingConfigs.getByName("debug"); isMinifyEnabled = false } }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies { implementation("androidx.appcompat:appcompat:1.7.0") }
