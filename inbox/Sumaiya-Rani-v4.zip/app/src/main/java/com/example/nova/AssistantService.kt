package com.example.nova

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class AssistantService : AccessibilityService() {
    companion object {
        @Volatile var instance: AssistantService? = null
        // Never automate these apps (add banking / wallet packages here or load from user settings)
        val blocked = mutableSetOf("com.android.vending")
        @Volatile var stopRequested = false
    }

    private var overlay: MarksView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlay = MarksView(this)
        wm.addView(overlay, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT))
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun showMarks(json: String) = main.post { runCatching { overlay?.set(JSONArray(json)) } }
    fun clearMarks() = main.post { overlay?.set(JSONArray()) }

    /** Android 11+ (API 30). Marks are cleared first so they don't appear in the capture. */
    @androidx.annotation.RequiresApi(30)
    fun screenshot(cb: (String?) -> Unit) {
        clearMarks()
        main.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    val hw = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hw, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    hw.close()
                    if (bmp == null) { cb(null); return }
                    val s = 1080f / maxOf(bmp.width, bmp.height)
                    val out = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true) else bmp
                    val bo = ByteArrayOutputStream()
                    out.compress(Bitmap.CompressFormat.JPEG, 70, bo)
                    cb(Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP))
                }
                override fun onFailure(code: Int) = cb(null)  // code 3 = called too fast (min ~1s apart)
            })
        }, 150)
    }

    private var stopBtn: android.widget.Button? = null

    /** Shows a red STOP button over every app while a task runs. */
    fun taskMode(on: Boolean) = main.post {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        stopBtn?.let { runCatching { wm.removeView(it) }; stopBtn = null }
        if (on) {
            stopRequested = false
            val b = android.widget.Button(this)
            b.text = "■ STOP"; b.setBackgroundColor(Color.rgb(255, 61, 61)); b.setTextColor(Color.WHITE)
            b.setOnClickListener { stopRequested = true; runCatching { wm.removeView(b) }; stopBtn = null }
            wm.addView(b, WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; y = 160 })
            stopBtn = b
        }
    }

    /** Executes ONE action the user already approved in the UI. Coordinates are fractions 0..1. */
    fun perform(a: JSONObject): Boolean {
        val pkg = rootInActiveWindow?.packageName?.toString()
        if (pkg != null && pkg in blocked) return false
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION") (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        fun px(k: String) = a.optDouble(k, 0.0).toFloat() * dm.widthPixels
        fun py(k: String) = a.optDouble(k, 0.0).toFloat() * dm.heightPixels
        return when (a.optString("type")) {
            "tap" -> gesture(Path().apply { moveTo(px("x"), py("y")) }, 60)
            "swipe" -> gesture(Path().apply { moveTo(px("x"), py("y")); lineTo(px("x2"), py("y2")) }, 350)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "text" -> {
                val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (n == null || n.isPassword) false else n.performAction(
                    AccessibilityNodeInfo.ACTION_SET_TEXT,
                    Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text")) })
            }
            else -> false
        }
    }

    private fun gesture(p: Path, ms: Long) = dispatchGesture(
        GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)

    /** Full-screen transparent view that draws the AI's annotations. */
    inner class MarksView(c: Context) : android.view.View(c) {
        private var marks = JSONArray()
        private val d = resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        private val hide = Runnable { set(JSONArray()) }

        fun set(m: JSONArray) { marks = m; invalidate(); main.removeCallbacks(hide); if (m.length() > 0) main.postDelayed(hide, 8000) }

        override fun onDraw(c: Canvas) {
            for (i in 0 until marks.length()) {
                val m = marks.optJSONObject(i) ?: continue
                val x = m.optDouble("x").toFloat() * width; val y = m.optDouble("y").toFloat() * height
                val s = (if (m.optString("s") == "l") 64f else 32f) * d   // large = important, small = secondary
                paint.strokeWidth = s / 6
                when (m.optString("t")) {
                    "check" -> { paint.color = Color.rgb(0, 230, 118)
                        c.drawPath(Path().apply { moveTo(x - s / 2, y); lineTo(x - s / 8, y + s / 2.5f); lineTo(x + s / 1.6f, y - s / 2) }, paint) }
                    "cross" -> { paint.color = Color.rgb(255, 61, 61)
                        c.drawLine(x - s / 2, y - s / 2, x + s / 2, y + s / 2, paint); c.drawLine(x + s / 2, y - s / 2, x - s / 2, y + s / 2, paint) }
                    "circle" -> { paint.color = Color.rgb(255, 63, 208); c.drawCircle(x, y, s, paint) }
                    "arrow" -> { paint.color = Color.rgb(255, 214, 0)
                        val x2 = m.optDouble("x2").toFloat() * width; val y2 = m.optDouble("y2").toFloat() * height
                        c.drawLine(x, y, x2, y2, paint)
                        val ang = Math.atan2((y2 - y).toDouble(), (x2 - x).toDouble()); val h = s / 2
                        for (side in doubleArrayOf(2.6, -2.6))
                            c.drawLine(x2, y2, x2 + (h * Math.cos(ang + side)).toFloat(), y2 + (h * Math.sin(ang + side)).toFloat(), paint) }
                }
            }
        }
    }
}
