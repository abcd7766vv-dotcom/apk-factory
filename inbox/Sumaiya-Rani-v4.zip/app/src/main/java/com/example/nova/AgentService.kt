package com.example.nova

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream

/** Foreground service: keeps Sumaiya Rani alive (Telegram) and owns the screen-capture permission (works on Android 5+). */
class AgentService : Service() {
    companion object { @Volatile var instance: AgentService? = null }
    private var proj: MediaProjection? = null

    fun ready() = proj != null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (Build.VERSION.SDK_INT >= 26)
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("agent", "Sumaiya Rani", NotificationManager.IMPORTANCE_LOW))
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "agent") else Notification.Builder(this)
        val n = b.setContentTitle("Sumaiya Rani is active").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        val data = i?.getParcelableExtra<Intent>("data")
        val code = i?.getIntExtra("code", 0) ?: 0
        if (Build.VERSION.SDK_INT >= 29 && data != null) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
        if (data != null && proj == null) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            proj = mgr.getMediaProjection(code, data)
        }
        instance = this
        return START_STICKY
    }

    /** One fresh frame per call, scaled to max 1080px, returned as base64 JPEG (or null). */
    @Suppress("DEPRECATION")
    fun capture(cb: (String?) -> Unit) {
        val p = proj ?: run { cb(null); return }
        Thread {
            var out: String? = null
            try {
                val dm = DisplayMetrics()
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
                val w = dm.widthPixels; val h = dm.heightPixels
                val rd = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
                val vd = p.createVirtualDisplay("cap", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null)
                var img: android.media.Image? = null
                var t = 0
                while (img == null && t++ < 30) { Thread.sleep(100); img = rd.acquireLatestImage() }
                img?.let {
                    val pl = it.planes[0]
                    val bmp = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(pl.buffer); it.close()
                    val crop = Bitmap.createBitmap(bmp, 0, 0, w, h)
                    val s = 1080f / maxOf(w, h)
                    val sm = if (s < 1f) Bitmap.createScaledBitmap(crop, (w * s).toInt(), (h * s).toInt(), true) else crop
                    val bo = ByteArrayOutputStream(); sm.compress(Bitmap.CompressFormat.JPEG, 70, bo)
                    out = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                }
                vd.release(); rd.close()
            } catch (e: Exception) { }
            cb(out)
        }.start()
    }

    override fun onDestroy() { proj?.stop(); instance = null; super.onDestroy() }
}
